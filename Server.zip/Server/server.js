//https 붙이기?
/* const fs = require('fs');
const https = require('https');
const httpsOptions = {
    key: fs.readFileSync('C:/Users/KDG/Desktop/Server/cert.key'),
    cert: fs.readFileSync('C:/Users/KDG/Desktop/Server/cert.crt')
}; */

//몽고DB + Node.js 연동 코드
const { MongoClient, ObjectId } = require("mongodb");
const express = require("express");
const path = require("path");
const app = express();

//body-parser 데이터 읽어오기
const bodyParser = require("body-parser");
app.use(bodyParser.json());

//로그인 세션 추가
const session = require("express-session");

app.use(
  session({
    secret: "dong", // 이 비밀키는 세션을 암호화하기 위해 사용됩니다.
    resave: false, // 세션이 변경되지 않아도 항상 저장할지 설정
    saveUninitialized: false, // 초기화되지 않은 세션을 스토어에 강제로 저장할지 설정
    cookie: {
      secure: false, // true로 설정하면 HTTPS에서만 쿠키 전송
      httpOnly: true, // 클라이언트 JavaScript가 쿠키를 볼 수 없도록 함
      maxAge: 24 * 60 * 60 * 1000, // 쿠키 유효기간
    },
  })
);

// MongoDB 연결 URI
const url =
  "mongodb+srv://dongkyu016634:0915@kimdonggyu.gtyow.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

const client = new MongoClient(url);

/*
//카카오 상담톡
Kakao.init('ac6c2cdfc307ec1b3bfdbc9fa562a9fe');
Kakao.isInitialized();
*/

async function startServer() {
  try {
    // MongoDB에 연결 시도
    await client.connect();
    console.log("몽고DB 접속 성공");

    // 데이터베이스 작업 추가 가능 (지우기)
    const db = client.db("myboard");
    const posts = db.collection("post");

    const bcrypt = require("bcryptjs"); // 비밀번호 암호화를 위해 필요
    /*
        //KAKAO API
        Kakao.API.request({
            url: '/v1/api/talk/channels',
          })
            .then(function(response) {
              console.log(response);
            })
            .catch(function(error) {
              console.log(error);
            });
*/

    // 로그인 API
    app.post("/login", async (req, res) => {
      const { email, userpw } = req.body;
      const users = db.collection("account"); // 올바른 컬렉션을 가리키도록 설정

      try {
        const user = await users.findOne({ email: email });
        if (user && bcrypt.compareSync(userpw, user.userpw)) {
          // 사용자 세션 설정
          req.session.userId = user._id;
          req.session.email = user.email;
          req.session.name = user.userid;
          req.session.nickname = user.nickname;
          req.session.phone = user.phone;
           // 세션 저장 내용
          res.redirect("/main"); // 로그인 성공 시 메인 페이지로 리다이렉트
        } else {
          res.status(401).send("아이디 또는 비밀번호가 잘못되었습니다.");
        }
      } catch (err) {
        console.error("로그인 에러:", err);
        res.status(500).send("서버 에러");
      }
    });

    //로그아웃 API(세션 종료)
    app.get("/logout", function (req, res) {
      req.session.destroy(function (err) {
        if (err) {
          console.error("세션 종료 에러:", err);
          return res.status(500).send("로그아웃 실패");
        }
        res.send(
          '<script>alert("로그아웃을 성공했습니다."); window.location.href="/";</script>'
        );
        //res.redirect('/index'); // 로그아웃 성공 시 홈페이지로 리다이렉트
      });
    });

    // 회원가입 API
    app.post("/register", async (req, res) => {
      const { email, userid, userpw, nickname, phone, gender } = req.body;
      if (
        !email ||
        !userid ||
        !userpw ||
        !phone ||
        !gender ||
        !email.includes("@")
      ) {
        return res.status(400).send("입력된 정보가 올바르지 않습니다.");
      }

      const hashedPassword = bcrypt.hashSync(userpw, 10); // 비밀번호 암호화
      const userDocument = {
        email,
        userid,
        userpw: hashedPassword,
        nickname,
        phone,
        gender,
      };

      try {
        const accounts = db.collection("account"); // 'account' 컬렉션 사용
        const result = await accounts.insertOne(userDocument);
        res.status(201).send("계정이 성공적으로 생성되었습니다.");
      } catch (error) {
        console.error("회원 가입 중 오류 발생:", error);
        res.status(500).send("회원 가입을 처리하는 중 오류가 발생했습니다.");
      }
    });

    // 게시글 저장 API
    app.post("/posts", async (req, res) => {
      try {
        const { category, title, author, content, createdAt, views } = req.body;
        const post = {
          category,
          title,
          author,
          content,
          createdAt,
          views,
        };
        const result = await db.collection("post").insertOne(post);
        res.status(201).json(result);
      } catch (err) {
        console.error("게시글 저장 실패:", err);
        res.status(500).json({ message: "게시글 저장에 실패했습니다." });
      }
    });

    // 게시글 저장 API (고객지원)
    app.post("/supports", async (req, res) => {
      try {
        const { category, title, author, content, createdAt, views } = req.body;
        const support = {
          category,
          title,
          author,
          content,
          createdAt,
          views,
        };
        const result = await db.collection("support").insertOne(support);
        res.status(201).json(result);
      } catch (err) {
        console.error("고객지원 글 저장 실패:", err);
        res.status(500).json({ message: "고객지원 글 저장에 실패했습니다." });
      }
    });

    // 로그인된 사용자의 닉네임 반환 API
    app.get("/get-nickname", (req, res) => {
      if (req.session.nickname) {
        res.json({ nickname: req.session.nickname });
      } else {
        res.status(401).send("로그인이 필요합니다.");
      }
    });

    // 로그인된 사용자의 이메일 반환 API
    app.get("/get-email", (req, res) => {
    if (req.session.email) {
      res.json({ email: req.session.email });
    } else {
      res.status(401).send("로그인이 필요합니다.");
    }
  });

   // 로그인된 사용자의 이름 반환 API
   app.get("/get-name", (req, res) => {
    if (req.session.name) {
      res.json({ name: req.session.name});
    } else {
      res.status(401).send("로그인이 필요합니다.");
    }
  });

    // 로그인된 사용자의 전화번호 반환 API
    app.get("/get-phone", (req, res) => {
      if (req.session.phone) {
        res.json({ phone: req.session.phone });
      } else {
        res.status(401).send("로그인이 필요합니다.");
      }
    }); 

    // 게시글 목록을 불러오는 API (카테고리 필터 추가)
    app.get("/posts", async (req, res) => {
      const { category } = req.query;
      let query = {};
      if (category && category !== "all") {
        query.category = category;
      }
      const posts = await db.collection("post").find(query).toArray();
      res.status(200).json(posts);
    });

    // 고객지원 게시글 목록 조회 API
    app.get("/supports", async (req, res) => {
      try {
        const { category } = req.query; // 카테고리 필터링 옵션을 받습니다.
        let query = {};
        if (category && category !== "all") {
          query.category = category; // 특정 카테고리에 해당하는 게시글만 필터링
        }
        const supports = await db.collection("support").find(query).toArray();
        res.json(supports);
      } catch (error) {
        console.error("고객지원 게시글 조회 실패:", error);
        res.status(500).send("서버 에러");
      }
    });

    app.get("/support/post", function (req, res) {
      const postId = req.query.id; // URL에서 id 쿼리 파라미터를 추출
      if (!postId) {
        return res.status(400).send("게시글 ID가 제공되지 않았습니다.");
      }

      // 데이터베이스에서 게시글을 찾고, 결과에 따라 페이지를 제공하거나 에러 메시지를 반환
      db.collection("support").findOne(
        { _id: new ObjectId(postId) },
        (err, doc) => {
          if (err) {
            console.error("게시글 조회 실패:", err);
            return res
              .status(500)
              .send("게시글을 조회하는 도중 오류가 발생했습니다.");
          }
          if (!doc) {
            return res.status(404).send("게시글을 찾을 수 없습니다.");
          }

          // 게시글 데이터와 함께 HTML 파일을 클라이언트에 제공
          res.sendFile(path.join(__dirname, "PUBLIC", "supportpost.html"));
        }
      );
    });

    // 개별 게시글을 불러오는 API
    app.get("/posts/:id", async (req, res) => {
      const postId = req.params.id;
      try {
        const post = await db
          .collection("post")
          .findOne({ _id: new ObjectId(postId) });
        if (post) {
          res.status(200).json(post);
        } else {
          res.status(404).send("게시글을 찾을 수 없습니다.");
        }
      } catch (err) {
        console.error("게시글 조회 실패:", err);
        res.status(500).send("서버 에러");
      }
    });

    // 게시글 조회수 업데이트 API
    app.post("/posts/:id/increment-view", async (req, res) => {
      try {
        const postId = req.params.id;
        const updateResult = await db
          .collection("post")
          .updateOne({ _id: new ObjectId(postId) }, { $inc: { views: 1 } });
        if (updateResult.modifiedCount === 1) {
          const updatedPost = await db
            .collection("post")
            .findOne({ _id: new ObjectId(postId) });
          res.status(200).json(updatedPost);
        } else {
          res.status(404).send("해당 게시글을 찾을 수 없습니다.");
        }
      } catch (err) {
        console.error("조회수 업데이트 중 에러 발생:", err);
        res.status(500).send("서버 에러");
      }
    });

    //댓글 추가 API
    app.post("/posts/:id/comments", async (req, res) => {
      const { id } = req.params;
      const { commentAuthor, commentContent } = req.body;

      if (!ObjectId.isValid(id)) {
        return res.status(400).send("잘못된 ID 형식입니다.");
      }

      try {
        const updateResult = await db
          .collection("post")
          .updateOne(
            { _id: new ObjectId(id) },
            {
              $push: {
                comments: {
                  author: commentAuthor,
                  content: commentContent,
                  createdAt: new Date(),
                },
              },
            }
          );

        if (updateResult.modifiedCount === 1) {
          res.status(200).send("댓글이 추가되었습니다.");
        } else {
          res.status(404).send("게시글을 찾을 수 없습니다.");
        }
      } catch (err) {
        console.error("댓글 추가 실패:", err);
        res.status(500).send("댓글 추가 중 서버 에러가 발생했습니다.");
      }
    });

       // 게시글 삭제를 처리하는 DELETE 요청
       app.delete("/posts/:id", async (req, res) => {
        const postId = req.params.id;
        if (!ObjectId.isValid(postId)) {
          return res.status(400).json({ success: false, message: "잘못된 ID 형식입니다." });
        }
      
        try {
          const deleteResult = await db.collection("post").deleteOne({ _id: new ObjectId(postId) });
          if (deleteResult.deletedCount === 1) {
            res.json({ success: true, message: "게시글이 성공적으로 삭제되었습니다." });
          } else {
            res.status(404).json({ success: false, message: "게시글을 찾을 수 없습니다." });
          }
        } catch (err) {
          console.error("게시글 삭제 에러:", err);
          res.status(500).json({ success: false, message: "게시글 삭제 중 서버 에러가 발생했습니다." });
        }
      });

    // MongoDB 연결 성공 후 Express 서버 설정
    app.use(express.static(path.join(__dirname, "PUBLIC")));
    app.use(express.static(path.join(__dirname, "PUBLIC", "signup")));

    // 라우트 설정(Node.js와 html 서버 연동)
    app.get("/", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "index.html"));
    });

    app.get("/board", function (req, res) {
      res.sendFile(path.join(__dirname, "BOARD", "board.html"));
    });

    app.get("/signup", function (req, res) {
      res.sendFile(path.join(__dirname, "public", "signup", "signup.html"));
    });

    app.get("/main", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "main.html"));
    });

    app.get("/support", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "support.html"));
    });

    app.get("/donnvol", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "donnvol.html"));
    });

    app.get("/mypage", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "mypage.html"));
    });

    app.get("/account", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "account.html"));
    });

    app.get("/subscribemanage", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "subscribemanage.html"));
    });

    app.get("/wish", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "wish.html"));
    });

    app.get("/watch", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "watch.html"));
    });

    app.get("/watch/video", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "video.html"));
    });

    app.get("/watch/movie", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "movie.html"));
    });

    app.get("/watch/series", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "series.html"));
    });

    // 정적 파일 제공을 위한 경로 설정
    app.use("/board", express.static(path.join(__dirname, "BOARD")));

    app.get("/board", async function (req, res) {
      try {
        const posts = await db.collection("post").find({}).toArray();
        res.render("board", { data: posts });
      } catch (err) {
        console.error("게시글 불러오기 실패:", err);
        res.status(500).send("서버 에러");
      }
    });

    app.get("/board/post", function (req, res) {
      res.sendFile(path.join(__dirname, "BOARD", "post.html"));
    });

    // 서버 8070 포트에서 대기

    app.listen(8070, function () {
      console.log("포트 8070으로 서버 대기중..");
    });
    /* https 서버 시작
        https.createServer(httpsOptions, app).listen(8070, () => {
            console.log('HTTPS server running on https://localhost:8070');
        });*/
  } catch (err) {
    console.error("몽고DB 접속 실패:", err);
    client.close();
    process.exit(1); // MongoDB 연결 실패 시 서버 시작을 중단
  }
}

// 서버 시작 함수 호출
startServer();

/*
//MySQL + Node.js 접속 코드
var mysql = require("mysql");
var conn = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"0915",
    database:"myboard",
});


conn.connect();
*/
