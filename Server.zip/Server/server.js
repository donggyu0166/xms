//https 붙이기?
/* const fs = require('fs');
const https = require('https');
const httpsOptions = {
    key: fs.readFileSync('C:/Users/KDG/Desktop/Server/cert.key'),
    cert: fs.readFileSync('C:/Users/KDG/Desktop/Server/cert.crt')
}; */

//몽고DB + Node.js 연동 코드
const { MongoClient, ObjectId } = require("mongodb");
const express = require("express");
const path = require("path");
const app = express();
const axios = require('axios');

const multer = require('multer');
const storage = multer.memoryStorage(); // 메모리에 파일 저장
const upload = multer({ storage: storage });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//body-parser 데이터 읽어오기
const bodyParser = require("body-parser");
app.use(bodyParser.json());

//로그인 세션 추가
const session = require("express-session");

app.use(
  session({
    secret: "dong", // 이 비밀키는 세션을 암호화하기 위해 사용됩니다.
    resave: false, // 세션이 변경되지 않아도 항상 저장할지 설정
    saveUninitialized: false, // 초기화되지 않은 세션을 스토어에 강제로 저장할지 설정
    cookie: { secure: false } // HTTPS 환경에서는 true로 설정
}));

// MongoDB 연결 URI
const url =
  "mongodb+srv://dongkyu016634:0915@kimdonggyu.gtyow.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

const client = new MongoClient(url);

async function startServer() {
  try {
    // MongoDB에 연결 시도
    await client.connect();
    console.log("몽고DB 접속 성공");

    // 데이터베이스 작업 추가 가능 (지우기)
    const db = client.db("myboard");
    const posts = db.collection("post");

    const bcrypt = require("bcryptjs"); // 비밀번호 암호화를 위해 필요
    
    const schedule = require('node-schedule');
    const moment = require('moment-timezone');
    const currentDateKST = moment().tz('Asia/Seoul').format('YYYY-MM-DD HH:mm:ss');
    
  async function checkAndUpdateSubscription() {
    const db = client.db("myboard");
    const accounts = db.collection("account");

    try {
      // 현재 날짜 가져오기
      const currentDate = new Date();
      
      // 구독 만료 사용자 찾기
      const expiredSubscriptions = await accounts.find({
        end_date: { $lte: currentDate },
        subscriber: true,
      }).toArray();

      // 만료된 사용자 구독 정보 업데이트
      const updateResult = await accounts.updateMany(
        { end_date: { $lte: currentDate }, subscriber: true },
        {
          $set: { subscriber: false },
          $unset: { start_date: "", end_date: "" },
        }
      );

      console.log("만료된 구독자 목록:", expiredSubscriptions);
      console.log(
        `${updateResult.modifiedCount} 구독 만료 사용자 상태가 업데이트되었습니다.`
      );
      } catch (error) {
        console.error("구독 상태 업데이트 중 오류 발생:", error);
      }
    }

    // 매일 자정에 실행
    // 매일 자정(KST)에 실행되도록 설정
    schedule.scheduleJob('0 0 * * *', () => {
      console.log("스케줄러 실행 (KST):", new Date());
      checkAndUpdateSubscription();
    });

    console.log("스케줄러 실행 시작 (현재 KST):", moment().tz("Asia/Seoul").format());
    checkAndUpdateSubscription();


    // 로그인 API
    app.post("/login", async (req, res) => {
      const { email, userpw } = req.body;
      const users = db.collection("account");
    
      try {
        const user = await users.findOne({ email: email });
        if (user && bcrypt.compareSync(userpw, user.userpw)) {
          // 사용자 세션 설정
          req.session.userId = user._id.toString();
          req.session.email = user.email;
          req.session.name = user.name;
          req.session.nickname = user.nickname;
          req.session.phone = user.phone;
          req.session.subscriber = user.subscriber;
          req.session.admin_state = user.admin_state;
          res.redirect("/main"); // 로그인 성공 시 메인 페이지로 리다이렉트
        } else {
          res.status(401).send("아이디 또는 비밀번호가 잘못되었습니다.");
        }
      } catch (err) {
        console.error("로그인 에러:", err);
        res.status(500).send("서버 에러");
      }
    });
    

    //로그아웃 API(세션 종료)
    app.get("/logout", function (req, res) {
      req.session.destroy(function (err) {
        if (err) {
          console.error("세션 종료 에러:", err);
          return res.status(500).send("로그아웃 실패");
        }
        res.send(
          '<script>alert("로그아웃을 성공했습니다."); window.location.href="/";</script>'
        );
        //res.redirect('/index'); // 로그아웃 성공 시 홈페이지로 리다이렉트
      });
    });

    // 회원가입 API
    // 서버 측 유효성 검사 함수 정의
    function validateEmail(email) {
      const emailPattern = /^[a-zA-Z0-9._+~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      return emailPattern.test(email);
    }
  
    function validateName(name) {
      const namePattern = /^[가-힣a-zA-Z]+$/;
      return namePattern.test(name);
    }

    function validateNickName(nickname) {
      const nicknamePattern = /^[가-힣a-zA-Z]+$/;
      return nicknamePattern.test(nickname); 
    }

    function validatePhone(phone) {
      const phonePattern = /^\d{3}-\d{4}-\d{4}$/; // 전화번호 형식 '000-0000-0000'
      return phonePattern.test(phone);
    }

    app.post("/register", async (req, res) => {
      const { email, name, userpw, nickname, phone, gender } = req.body;
    
      // 서버 측 유효성 검사
      if (
        !validateEmail(email) ||
        !validateName(name) ||
        !validateNickName(nickname) ||
        !validatePhone(phone) ||
        !gender ||
        !userpw
      ) {
        console.log("잘못된 입력 정보");
        return res.status(400).send("입력된 정보가 올바르지 않습니다.");
      }
    
      try {
        const accounts = db.collection("account");
    
        // 이메일 및 닉네임 중복 확인
        const existingUser = await accounts.findOne({
          $or: [{ email: email }, { nickname: nickname }]
        });
        if (existingUser) {
          if (existingUser.email === email) {
            return res.status(409).send("중복된 이메일이 있습니다. 다른 이메일을 입력해 주세요.");
          }
          if (existingUser.nickname === nickname) {
            return res.status(409).send("중복된 닉네임이 있습니다. 다른 닉네임을 입력해 주세요.");
          }
        }
    
        // 중복이 없는 경우 사용자 추가
        const hashedPassword = bcrypt.hashSync(userpw, 10);
        const userDocument = {
          email,
          name,
          userpw: hashedPassword,
          nickname,
          phone,
          gender,
          subscriber: false,
          admin_state: false
        };
    
        const result = await accounts.insertOne(userDocument);
        res.status(201).send("계정이 성공적으로 생성되었습니다.");
      } catch (error) {
        console.error("회원 가입 중 오류 발생:", error);
        res.status(500).send("회원 가입을 처리하는 중 오류가 발생했습니다.");
      }
    });
    
    app.get("/check-duplicate", async (req, res) => {
      const { email, nickname } = req.query;
      const accounts = db.collection("account");
    
      try {
        if (email) {
          const existingEmail = await accounts.findOne({ email: email });
          if (existingEmail) {
            return res.send("중복된 이메일이 있습니다. 다른 이메일을 입력해 주세요.");
          } else {
            return res.send("중복된 이메일이 없습니다.");
          }
        }
    
        if (nickname) {
          const existingNickname = await accounts.findOne({ nickname: nickname });
          if (existingNickname) {
            return res.send("중복된 닉네임이 있습니다. 다른 닉네임을 입력해 주세요.");
          } else {
            return res.send("중복된 닉네임이 없습니다.");
          }
        }
      } catch (error) {
        console.error("중복 확인 중 오류 발생:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
      }
    });

    //계정 찾기
    app.post("/find-id", async (req, res) => {
      const { name, phone } = req.body;
  
      if (!name || !phone) {
          return res.status(400).send("모든 정보를 입력해 주세요.");
      }
  
      try {
          const accounts = client.db("myboard").collection("account");
          const formattedPhone = phone.join("-"); // 전화번호 조합
          const user = await accounts.findOne({ name: name, phone: formattedPhone, admin_state: false });
  
          if (user) {
              res.status(200).json({ email: user.email });
          } else {
              res.status(404).send("해당하는 계정을 찾을 수 없습니다.");
          }
      } catch (error) {
          console.error("아이디 찾기 오류:", error);
          res.status(500).send("서버 오류가 발생했습니다.");
      }
  });
  
  
  

    //비밀번호 찾기
    app.post("/reset-password", async (req, res) => {
      const { email, phone, newPassword } = req.body;
  
      if (!email || !phone || !newPassword) {
          return res.status(400).send("모든 정보를 입력해 주세요.");
      }
  
      try {
          const accounts = client.db("myboard").collection("account");
          const formattedPhone = phone.join("-");
          const user = await accounts.findOne({
              email: email,
              phone: formattedPhone,
              admin_state: false, // 관리자 계정 제외
          });
  
          if (!user) {
              return res.status(404).send("해당하는 계정을 찾을 수 없습니다.");
          }
  
          const hashedPassword = bcrypt.hashSync(newPassword, 10);
          const result = await accounts.updateOne(
              { _id: user._id },
              { $set: { userpw: hashedPassword } }
          );
  
          if (result.modifiedCount === 1) {
              res.status(200).send("비밀번호가 성공적으로 변경되었습니다.");
          } else {
              res.status(500).send("비밀번호 변경 중 오류가 발생했습니다.");
          }
      } catch (error) {
          console.error("비밀번호 재설정 오류:", error);
          res.status(500).send("서버 오류가 발생했습니다.");
      }
  });
  
  
  


    //계정 정보 수정 API
    app.put("/update-account", async (req, res) => {
      if (!req.session.userId) {
          return res.status(401).send("로그인이 필요합니다.");
      }
  
      const { newNickname, newPhone, newPassword } = req.body;
      const updateFields = {};
  
      try {
          const accounts = db.collection("account");
          const posts = db.collection("post");
          const user = await accounts.findOne({ _id: new ObjectId(req.session.userId) });
  
          if (!user) {
              return res.status(404).send("계정을 찾을 수 없습니다.");
          }

      // 입력한 닉네임이 기존과 같은지 확인
        if (newNickname && newNickname === user.nickname) {
          return res.status(409).send("새로운 닉네임이 기존 닉네임과 동일합니다. 다른 닉네임을 입력해 주세요.");
      }

      // 입력한 전화번호가 기존과 같은지 확인
      if (newPhone && newPhone.join('-') === user.phone) {
          return res.status(409).send("새로운 전화번호가 기존 전화번호와 동일합니다. 다른 전화번호를 입력해 주세요.");
      }

      // 입력한 비밀번호가 기존과 같은지 확인 (비밀번호 암호화 비교)
      if (newPassword && bcrypt.compareSync(newPassword, user.userpw)) {
          return res.status(409).send("새로운 비밀번호가 기존 비밀번호와 동일합니다. 다른 비밀번호를 입력해 주세요.");
      }

      // 전화번호 유효성 검사
      if (newPhone && newPhone[0] && newPhone[1] && newPhone[2]) {
        const phone = `${newPhone[0]}-${newPhone[1]}-${newPhone[2]}`;
        if (/^\d{3}-\d{4}-\d{4}$/.test(phone)) {
            updateFields.phone = phone;
        } else {
            return res.status(400).send("전화번호는 숫자로만 입력해 주세요.");
        }
    }
  
      // 닉네임 중복 확인
      if (newNickname && newNickname !== user.nickname) {
        const existingNickname = await accounts.findOne({
          nickname: newNickname,
          _id: { $ne: new ObjectId(req.session.userId) }
        });
        if (existingNickname) {
          return res.status(409).send("중복된 닉네임이 있습니다. 다른 닉네임을 입력해 주세요.");
          }
          updateFields.nickname = newNickname;
      }
  
      // 전화번호 변경 확인
      if (newPhone && newPhone[0] && newPhone[1] && newPhone[2]) {
          updateFields.phone = `${newPhone[0]}-${newPhone[1]}-${newPhone[2]}`;
        } else {
         // 전화번호 필드가 비어있거나 입력되지 않았다면 업데이트하지 않음
         updateFields.phone = user.phone;
       }
  
      // 비밀번호 변경 확인
      if (newPassword) {
        updateFields.userpw = bcrypt.hashSync(newPassword, 10);
        }
  
        const result = await accounts.updateOne(
          { _id: new ObjectId(req.session.userId) },
          { $set: updateFields }
      );
  
      if (result.modifiedCount === 1) {
      // 세션 정보 업데이트
        if (updateFields.nickname) req.session.nickname = updateFields.nickname;
        if (updateFields.phone) req.session.phone = updateFields.phone;
           res.send("계정 정보가 성공적으로 수정되었습니다.");
       } else {
          res.status(500).send("계정 수정 중 오류가 발생했습니다.");
        }
      } catch (error) {
          console.error("계정 수정 중 오류 발생:", error);
          res.status(500).send("계정 수정 중 오류가 발생했습니다.");
      }
  });
  
    // 회원탈퇴 API
    app.delete("/delete-account", async (req, res) => {
      if (!req.session.userId) {
          return res.status(401).send("로그인이 필요합니다.");
      }
  
      try {
          const accounts = db.collection("account");
          const deleteResult = await accounts.deleteOne({ _id: new ObjectId(req.session.userId) });
  
          if (deleteResult.deletedCount === 1) {
              req.session.destroy((err) => {
                  if (err) {
                      return res.status(500).send("회원 탈퇴 실패");
                  }
                  res.redirect("/"); // 탈퇴 성공 시 메인 페이지로 이동
              });
          } else {
              res.status(404).send("사용자를 찾을 수 없습니다.");
          }
      } catch (error) {
          console.error("회원 탈퇴 중 오류 발생:", error);
          res.status(500).send("회원 탈퇴 중 서버 오류가 발생했습니다.");
      }
  });
  
  
    // 게시글 저장 API
    app.post("/posts", async (req, res) => {
      try {
        const { category, title, author, content, createdAt, views } = req.body;
       
        const email = req.session.email;
        if (!email) {
          return res.status(401).send("로그인이 필요합니다."); // 로그인 여부 확인
        }
        const post = {
          category,
          title,
          author,
          content,
          createdAt,
          views,
          email,
        };
        const result = await db.collection("post").insertOne(post);
        res.status(201).json(result);
      } catch (err) {
        console.error("게시글 저장 실패:", err);
        res.status(500).json({ message: "게시글 저장에 실패했습니다." });
      }
    });

    // 게시글 저장 API (고객지원)
    app.post("/supports", async (req, res) => {
      try {
        const { category, title, author, content, createdAt, views } = req.body;
    
        // 세션에서 이메일 가져오기
        const email = req.session.email;
        if (!email) {
          return res.status(401).send("로그인이 필요합니다."); // 로그인 여부 확인
        }
    
        // support document 생성
        const support = {
          category,
          title,
          author,
          content,
          createdAt,
          views,
          email, // 이메일 필드 추가
        };
    
        // DB에 저장
        const result = await db.collection("support").insertOne(support);
        res.status(201).json(result);
      } catch (err) {
        console.error("고객지원 글 저장 실패:", err);
        res.status(500).json({ message: "고객지원 글 저장에 실패했습니다." });
      }
    });


    // 로그인된 사용자의 닉네임 반환 API
    app.get("/get-nickname", (req, res) => {
      if (req.session.nickname) {
        res.json({ nickname: req.session.nickname });
      } else {
        res.status(401).send("로그인이 필요합니다.");
      }
    });

    // 로그인된 사용자의 이메일 반환 API
    app.get("/get-email", (req, res) => {
    if (req.session.email) {
      res.json({ email: req.session.email });
    } else {
      res.status(401).send("로그인이 필요합니다.");
    }
  });

   // 로그인된 사용자의 이름 반환 API
   app.get("/get-name", (req, res) => {
    if (req.session.name) {
      res.json({ name: req.session.name});
    } else {
      res.status(401).send("로그인이 필요합니다.");
    }
  });

    // 로그인된 사용자의 전화번호 반환 API
    app.get("/get-phone", (req, res) => {
      if (req.session.phone) {
        res.json({ phone: req.session.phone });
      } else {
        res.status(401).send("로그인이 필요합니다.");
      }
    });
    

    // 로그인된 사용자의 이메일, 이름, 전화번호 반환 API
    app.get("/get-user-info", (req, res) => {
      if (req.session.userId) {
        const accounts = db.collection("account");
        accounts.findOne({ _id: new ObjectId(req.session.userId) })
          .then(user => {
            if (!user) return res.status(404).send("User not found");
            res.json({
              email: user.email,
              name: user.name,
              phone: user.phone,
              admin_state: user.admin_state,
            });
          })
          .catch(error => {
            console.error("Error fetching user info:", error);
            res.status(500).send("Server error");
          });
      } else {
        res.status(401).send("로그인이 필요합니다.");
      }
    });

    // 프로필 변경
    app.post("/upload-profile-pic", upload.single("profilePic"), async (req, res) => {
      if (!req.session.userId) {
          return res.status(401).send("로그인이 필요합니다.");
      }
  
      const file = req.file;
  
      if (!file) {
          return res.status(400).send("파일이 업로드되지 않았습니다.");
      }
  
      try {
          const accounts = client.db("myboard").collection("account");
  
          // 프로필 사진 데이터 저장
          const updateResult = await accounts.updateOne(
              { _id: new ObjectId(req.session.userId) },
              {
                  $set: {
                      profile_pic: {
                          data: file.buffer,
                          contentType: file.mimetype,
                      },
                  },
              }
          );
  
          if (updateResult.modifiedCount === 1) {
              res.status(200).send("프로필 사진이 성공적으로 업데이트되었습니다.");
          } else {
              res.status(500).send("프로필 사진 업데이트에 실패했습니다.");
          }
      } catch (error) {
          console.error("프로필 사진 업로드 오류:", error);
          res.status(500).send("서버 오류가 발생했습니다.");
      }
  });


  app.get("/get-profile-pic", async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).send("로그인이 필요합니다.");
    }

    try {
        const accounts = client.db("myboard").collection("account");
        const user = await accounts.findOne(
            { _id: new ObjectId(req.session.userId) },
            { projection: { profile_pic: 1 } }
        );

        if (user && user.profile_pic && user.profile_pic.data) {
            const base64Image = `data:${user.profile_pic.contentType};base64,${Buffer.from(user.profile_pic.data.buffer).toString("base64")}`;
            return res.status(200).json({ profilePic: base64Image });
        } else {
            // 프로필 사진이 없으면 기본 이미지 URL 반환
            return res.status(200).json({ profilePic: null });
        }
    } catch (error) {
        console.error("프로필 사진 가져오기 실패:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

  


    // 관리자 페이지
    app.get("/admin/members", async (req, res) => {
      if (!req.session.admin_state) {
          return res.status(403).json({ error: "관리자만 접근할 수 있습니다." });
      }
      try {
          const accounts = client.db("myboard").collection("account");
          const members = await accounts.find({}, { projection: { name: 1, email: 1, gender: 1, phone: 1, _id: 0 } }).toArray();
          res.json(members);
      } catch (error) {
          console.error("회원 목록 조회 오류:", error);
          res.status(500).json({ error: "회원 목록을 불러오는 중 오류가 발생했습니다." });
      }
  });

  app.get("/admin/subscribers", async (req, res) => {
    if (!req.session.admin_state) {
        return res.status(403).json({ error: "관리자만 접근할 수 있습니다." });
    }
    try {
        const accounts = client.db("myboard").collection("account");
        const subscribers = await accounts.find(
            { subscriber: true },
            { projection: { name: 1, start_date: 1, end_date: 1, _id: 0 } }
        ).toArray();
        res.json(subscribers);
    } catch (error) {
        console.error("구독 현황 조회 오류:", error);
        res.status(500).json({ error: "구독 현황을 불러오는 중 오류가 발생했습니다." });
    }
});

app.get("/admin/expiring-subscribers", async (req, res) => {
  if (!req.session.admin_state) {
      return res.status(403).json({ error: "관리자만 접근할 수 있습니다." });
  }

  try {
      // 현재 날짜 계산
      const currentDate = new Date();

      const accounts = client.db("myboard").collection("account");
      const expiringSubscribers = await accounts.find(
          {
              subscriber: true,
              end_date: { $gte: currentDate } // 종료일이 현재 날짜 이후
          },
          { projection: { name: 1, end_date: 1, _id: 0 } }
      ).toArray();

      // 남은 날짜 계산 및 필터링
      const filteredSubscribers = expiringSubscribers
          .map(subscriber => {
              const endDate = new Date(subscriber.end_date);
              const remainingDays = Math.ceil((endDate - currentDate) / (1000 * 60 * 60 * 24));
              return { ...subscriber, remaining_days: remainingDays };
          })
          .filter(subscriber => subscriber.remaining_days <= 7); // 7일 이하인 경우만 필터링

      res.json(filteredSubscribers);
  } catch (error) {
      console.error("구독 만료 예정자 조회 오류:", error);
      res.status(500).json({ error: "구독 만료 예정자를 불러오는 중 오류가 발생했습니다." });
  }
});



    // 게시글 목록을 불러오는 API (카테고리 필터 추가)
    app.get("/posts", async (req, res) => {
      const { category } = req.query;
      let query = {};
      if (category && category !== "all") {
          query.category = category;
      }
      const posts = await db.collection("post").find(query).sort({ createdAt: -1 }).toArray();
      res.status(200).json(posts);
  });
  

      // 게시글 목록을 불러오는 API (카테고리 필터 추가)
      app.get("/supports", async (req, res) => {
        const { category } = req.query; // Get category from query parameters
        let query = {};
        if (category && category !== "all") {
            query.category = category; // Example: "Q&A"
        }
        try {
            const supports = await db.collection("support")
                .find(query)
                .sort({ createdAt: -1 }) // Sort by creation date (most recent first)
                .toArray();
            res.status(200).json(supports);
        } catch (err) {
            console.error("게시글 불러오기 실패:", err);
            res.status(500).send("서버 에러");
        }
    });
    

    // 개별 게시글을 불러오는 API
    app.get("/posts/:id", async (req, res) => {
      const postId = req.params.id;
      try {
        const post = await db
          .collection("post")
          .findOne({ _id: new ObjectId(postId) });
        if (post) {
          res.status(200).json(post);
        } else {
          res.status(404).send("게시글을 찾을 수 없습니다.");
        }
      } catch (err) {
        console.error("게시글 조회 실패:", err);
        res.status(500).send("서버 에러");
      }
    });

        // 개별 게시글을 불러오는 API
        app.get("/supports/:id", async (req, res) => {
          const supportId = req.params.id;
      
          if (!ObjectId.isValid(supportId)) {
              return res.status(400).send("Invalid support ID.");
          }
      
          try {
              const support = await db.collection("support").findOne(
                  { _id: new ObjectId(supportId) },
                  { projection: { comments: 1, title: 1, author: 1, createdAt: 1, views: 1, content: 1 } } // Include comments
              );
              if (!support) {
                  return res.status(404).send("Support post not found.");
              }
              res.status(200).json(support);
          } catch (error) {
              console.error("Error fetching support post:", error);
              res.status(500).send("Server error.");
          }
      });
      

    // 게시글 조회수 업데이트 API
    app.post("/posts/:id/increment-view", async (req, res) => {
      try {
        const postId = req.params.id;
        const updateResult = await db
          .collection("post")
          .updateOne({ _id: new ObjectId(postId) }, { $inc: { views: 1 } });
        if (updateResult.modifiedCount === 1) {
          const updatedPost = await db
            .collection("post")
            .findOne({ _id: new ObjectId(postId) });
          res.status(200).json(updatedPost);
        } else {
          res.status(404).send("해당 게시글을 찾을 수 없습니다.");
        }
      } catch (err) {
        console.error("조회수 업데이트 중 에러 발생:", err);
        res.status(500).send("서버 에러");
      }
    });

    app.post("/supports/:id/increment-view", async (req, res) => {
      try {
        const supportId = req.params.id;
        const updateResult = await db
          .collection("support")
          .updateOne({ _id: new ObjectId(supportId) }, { $inc: { views: 1 } });
        if (updateResult.modifiedCount === 1) {
          const updatedPost = await db
            .collection("support")
            .findOne({ _id: new ObjectId(supportId) });
          res.status(200).json(updatedPost);
        } else {
          res.status(404).send("해당 게시글을 찾을 수 없습니다.");
        }
      } catch (err) {
        console.error("조회수 업데이트 중 에러 발생:", err);
        res.status(500).send("서버 에러");
      }
    });

    //댓글 추가 API
    app.post("/posts/:id/comments", async (req, res) => {
      const { id } = req.params;
      const { commentContent } = req.body;
    
      if (!ObjectId.isValid(id)) {
        return res.status(400).send("Invalid post ID.");
      }
    
      try {
        const commentAuthor = req.session.nickname || "익명"; // Use session nickname or fallback to '익명'
    
        const updateResult = await db.collection("post").updateOne(
          { _id: new ObjectId(id) },
          {
            $push: {
              comments: {
                author: commentAuthor,
                content: commentContent,
                createdAt: new Date(),
              },
            },
          }
        );
    
        if (updateResult.modifiedCount === 1) {
          res.status(201).send("Comment added successfully.");
        } else {
          res.status(404).send("Post not found.");
        }
      } catch (error) {
        console.error("Error adding comment:", error);
        res.status(500).send("Server error.");
      }
    });
    // Get comments for a specific post
    app.get("/posts/:id/comments", async (req, res) => {
      const { id } = req.params;
    
      if (!ObjectId.isValid(id)) {
        return res.status(400).send("Invalid post ID.");
      }
    
      try {
        const post = await db.collection("post").findOne(
          { _id: new ObjectId(id) },
          { projection: { comments: 1 } } // Only fetch the comments field
        );
    
        if (post) {
          res.status(200).json(post.comments || []);
        } else {
          res.status(404).send("Post not found.");
        }
      } catch (error) {
        console.error("Error fetching comments:", error);
        res.status(500).send("Server error.");
      }
    });
    app.post("/supports/:id/comments", async (req, res) => {
      const { id } = req.params;
      const { content } = req.body;
    
      if (!ObjectId.isValid(id)) {
        return res.status(400).send("Invalid support ID.");
      }
    
      if (!req.session.userId) {
        return res.status(401).send("로그인이 필요합니다.");
      }
    
      try {
        const accounts = db.collection("account");
        const user = await accounts.findOne({ _id: new ObjectId(req.session.userId) });
    
        if (!user || !user.admin_state) {
          return res.status(403).json({ message: "Only administrators can reply." });
        }
    
        const newComment = {
          author: user.nickname || "익명",
          content,
          createdAt: new Date(),
        };
    
        const updateResult = await db.collection("support").updateOne(
          { _id: new ObjectId(id) },
          { $push: { comments: newComment } }
        );
    
        if (updateResult.modifiedCount === 1) {
          res.status(201).json(newComment);
        } else {
          res.status(404).send("Support post not found.");
        }
      } catch (error) {
        console.error("Error adding comment:", error);
        res.status(500).send("Server error.");
      }
    });
    
    app.get("/supports/:id/comments", async (req, res) => {
      const { id } = req.params;
    
      if (!ObjectId.isValid(id)) {
        return res.status(400).send("Invalid support ID.");
      }
    
      try {
        const support = await db.collection("support").findOne(
          { _id: new ObjectId(id) },
          { projection: { comments: 1 } } // Fetch only comments field
        );
    
        if (support) {
          res.status(200).json(support.comments || []);
        } else {
          res.status(404).send("Support post not found.");
        }
      } catch (error) {
        console.error("Error fetching comments:", error);
        res.status(500).send("Server error.");
      }
    });
    

    app.delete("/posts/:id", async (req, res) => {
      const postId = req.params.id;
    
      // Validate the post ID format
      if (!ObjectId.isValid(postId)) {
        return res.status(400).json({ success: false, message: "Invalid post ID format." });
      }
    
      if (!req.session.email) {
        return res.status(401).json({ success: false, message: "Login required." });
      }
    
      try {
        // Find the post to check the author
        const post = await db.collection("post").findOne({ _id: new ObjectId(postId) });
    
        if (!post) {
          return res.status(404).json({ success: false, message: "Post not found." });
        }
    
        // Check if the logged-in user is the author or an administrator
        if (req.session.email === post.email || req.session.admin_state) {
          // Proceed with deletion
          const deleteResult = await db.collection("post").deleteOne({ _id: new ObjectId(postId) });
    
          if (deleteResult.deletedCount === 1) {
            return res.json({ success: true, message: "Post deleted successfully." });
          } else {
            return res.status(404).json({ success: false, message: "Failed to delete the post." });
          }
        } else {
          return res.status(403).json({ success: false, message: "You do not have permission to delete this post." });
        }
      } catch (err) {
        console.error("Error deleting post:", err);
        res.status(500).json({ success: false, message: "Server error occurred while deleting the post." });
      }
    });
    
  

      // Delete a post by ID
      app.delete("/supports/:id", async (req, res) => {
        const { id } = req.params;
        if (!ObjectId.isValid(id)) {
            return res.status(400).send("Invalid support ID");
        }
    
        try {
            const support = await db.collection("support").findOne({ _id: new ObjectId(id) });
    
            if (!support) {
                return res.status(404).send("Support post not found.");
            }
    
            // Check if the current session's email matches the support post's author email or if the user is an admin
            if (req.session.email === support.email || req.session.admin_state) {
                const deleteResult = await db.collection("support").deleteOne({ _id: new ObjectId(id) });
    
                if (deleteResult.deletedCount === 1) {
                    res.send({ success: true, message: "Support post deleted successfully" });
                } else {
                    res.status(404).send({ success: false, message: "Support post not found" });
                }
            } else {
                res.status(403).send("You are not authorized to delete this post.");
            }
        } catch (error) {
            console.error("Error deleting support post:", error);
            res.status(500).send("Server error");
        }
    });


    
    //기부 인증 게시판
    app.post('/donation-certification', upload.single('image'), async (req, res) => {
      const { title, content } = req.body;
      const { file } = req;
      const image = file ? { data: file.buffer, contentType: file.mimetype } : {};
    
      if (!req.session.userId) {
        return res.status(401).send("로그인이 필요합니다.");
      }
    
      const db = client.db("myboard");
      const certificationCollection = db.collection("Donation_Certification");
    
      try {
        const doc = {
            title,
            image,
            content,
            createdAt: new Date(),
        };
    
        const result = await certificationCollection.insertOne(doc);
        if (result.acknowledged) {
            res.status(201).send("인증 글이 성공적으로 저장되었습니다.");
        } else {
            res.status(400).send("인증 글 저장에 실패했습니다.");
        }
      } catch (error) {
        console.error("인증 글 저장 중 오류 발생:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
      }
    });
    
    app.get('/api/certifications', async (req, res) => {
      const db = client.db("myboard");
      const collection = db.collection("Donation_Certification");
      const certifications = await collection.find({}).toArray();
      
      const modifiedCertifications = certifications.map(cert => {
          if (cert.image && cert.image.data) {
              // MongoDB에서 불러온 Buffer 데이터를 Base64 문자열로 변환
              cert.image = `data:${cert.image.contentType};base64,${cert.image.data.toString('base64')}`;
          }
          return cert;
      });
  
      res.json(modifiedCertifications);
  });
  

  app.get("/api/recent-posts", async (req, res) => {
    try {
        const db = client.db("myboard");
        const posts = await db.collection("post")
            .find({})
            .sort({ createdAt: -1 }) // 생성일 기준 내림차순 정렬
            .limit(4) // 최근 4개만 가져오기
            .toArray();

        res.status(200).json(posts);
    } catch (error) {
        console.error("Error fetching recent posts:", error);
        res.status(500).send("Error fetching recent posts");
    }
});


    // 사용자의 구독 상태를 반환하는 API
    app.get("/get-subscriber-status", (req, res) => {
      if (req.session.userId) {
          const accounts = db.collection("account");
          accounts.findOne({ _id: new ObjectId(req.session.userId) })
              .then(user => {
                  if (!user) return res.status(404).send("User not found");
  
                  const nextPaymentDate = user.end_date
                      ? new Date(new Date(user.end_date).getTime() + 24 * 60 * 60 * 1000)
                      : null;
  
                  res.json({
                      subscriber: user.subscriber,
                      start_date: user.start_date,
                      end_date: user.end_date,
                      next_payment_date: nextPaymentDate
                  });
              })
              .catch(error => {
                  console.error("Error fetching subscriber status:", error);
                  res.status(500).send("Server error");
              });
        } else {
          res.status(401).send("로그인이 필요합니다.");
        }
    });
  
    // 기부 내역 불러오기
    app.get("/get-donation-history", async (req, res) => {
      if (!req.session.userId) {
          return res.status(401).send("로그인이 필요합니다.");
      }
    
      try {
          const accounts = client.db("myboard").collection("account");
          const user = await accounts.findOne(
              { _id: new ObjectId(req.session.userId) },
              { projection: { donation_history: 1, _id: 0 } }
          );
    
          if (!user || !user.donation_history || user.donation_history.length === 0) {
              return res.json([]); // 빈 배열 반환
          }
    
          res.json(user.donation_history);
      } catch (error) {
          console.error("기부 내역 불러오기 실패:", error);
          res.status(500).send("서버 오류가 발생했습니다.");
      }
    });
    
    // 구독 내역 불러오기
    app.get("/get-subscription-history", async (req, res) => {
      if (!req.session.userId) {
          return res.status(401).send("로그인이 필요합니다.");
      }
  
      try {
          const accounts = client.db("myboard").collection("account");
          const user = await accounts.findOne(
              { _id: new ObjectId(req.session.userId) },
              { projection: { sub_history: 1, _id: 0 } }
          );
  
          if (!user || !user.sub_history || user.sub_history.length === 0) {
              return res.json([]); // 빈 배열 반환
          }
  
          res.json(user.sub_history);
      } catch (error) {
          console.error("구독 내역 불러오기 실패:", error);
          res.status(500).send("서버 오류가 발생했습니다.");
      }
  });
  

  app.get("/get-latest-subscription", async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).send("로그인이 필요합니다.");
    }

    try {
        const accounts = client.db("myboard").collection("account");
        const user = await accounts.findOne(
            { _id: new ObjectId(req.session.userId) },
            { projection: { sub_history: 1, _id: 0 } }
        );

        if (!user || !user.sub_history || user.sub_history.length === 0) {
            return res.json({ pay_name: "구독 내역이 없습니다." });
        }

        // sub_history 배열에서 마지막 항목 반환
        const latestSubscription = user.sub_history[user.sub_history.length - 1];
        res.json(latestSubscription);
    } catch (error) {
        console.error("최신 구독 내역 불러오기 실패:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

  
  app.post("/cancel-subscription", async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ success: false, message: "로그인이 필요합니다." });
    }

    const db = client.db("myboard");
    const accounts = db.collection("account");

    const user = await accounts.findOne({ _id: new ObjectId(req.session.userId) });
    if (!user) {
        return res.status(404).json({ success: false, message: "계정을 찾을 수 없습니다." });
    }

    if (user.subscriber) {
        const updateResult = await accounts.updateOne(
            { _id: new ObjectId(req.session.userId) },
            { $set: { subscriber: false }, $unset: { start_date: "", end_date: "" } }
        );
        if (updateResult.modifiedCount === 1) {
            req.session.subscriber = false;
            res.json({ success: true, message: "구독이 성공적으로 취소되었습니다." });
        } else {
            res.status(500).json({ success: false, message: "구독 취소에 실패했습니다." });
        }
    } else {
        res.json({ success: false, message: "현재 구독 중이 아닙니다." });
      }
  });

  function requireSubscription(req, res, next) {
    if (req.session && req.session.subscriber) {
      next(); // 구독 상태가 true이면 다음 미들웨어로 이동
    } else {
      res.status(403).send(
        '<script>alert("구독자만 접근할 수 있는 페이지입니다."); window.location.href="/main";</script>'
      ); // 구독 상태가 아니면 접근 제한
    }
  }

  // 리더보드
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const accounts = client.db("myboard").collection("account");
  
      const users = await accounts
        .find(
          { admin_state: false }, // 관리자가 아닌 사용자
          { projection: { nickname: 1, donation_history: 1 } }
        )
        .toArray();
  
      const leaderboard = users.map((user) => {
        const totalDonation = user.donation_history
          ? user.donation_history.reduce((sum, donation) => sum + donation.donation_amount, 0)
          : 0;
        return {
          nickname: user.nickname,
          totalDonation,
        };
      });
  
      // 기부금 기준으로 정렬하고 상위 10명 반환
      const sortedLeaderboard = leaderboard
        .sort((a, b) => b.totalDonation - a.totalDonation)
        .slice(0, 10);
  
      res.status(200).json(sortedLeaderboard);
    } catch (error) {
      console.error("리더보드 데이터 가져오기 실패:", error);
      res.status(500).send("리더보드 데이터를 가져오는 중 오류가 발생했습니다.");
    }
  });
  

  // 기부
  app.post("/donation/complete", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).send("로그인이 필요합니다.");
    }
  
    const { imp_uid, merchant_uid, amount } = req.body;
  
    try {
      // IAMPORT에서 액세스 토큰 발급
      const getToken = await axios({
        url: "https://api.iamport.kr/users/getToken",
        method: "post",
        headers: { "Content-Type": "application/json" },
        data: {
          imp_key: "1471171078525537",
          imp_secret: "Mb4B4gD5toMmhYPVl3n58GizvTvRPHAeLsOUI2dNmgommP6qbvVESOCQFn9u7C6Rz7KArvGmG0IgF3rM"
        },
      });
  
      const { access_token } = getToken.data.response;
  
      // 결제 정보 검증
      const getPaymentData = await axios({
        url: `https://api.iamport.kr/payments/${imp_uid}`,
        method: "get",
        headers: { Authorization: access_token },
      });
  
      const paymentData = getPaymentData.data.response;
  
      if (paymentData.status === "paid") {
        const db = client.db("myboard");
        const accounts = db.collection("account");

        // 현재 날짜와 한 달 후 날짜 계산
        const startDate = new Date();

        // 데이터베이스에서 사용자 정보 업데이트
        const updateResult = await accounts.updateOne(
            { _id: new ObjectId(req.session.userId) },
            {
                $push: {
                  donation_history: {
                      donation_name: "생태계 교란종 거북이들이 하천 생명을 위협하고 있어요", // 기부명
                      donation_date: new Date(),  // 결제 날짜
                      donation_amount: amount
                  }
              }
          }
        );
        res.status(200).send("기부가 성공적으로 완료되었습니다.");
      } else {
        res.status(400).send("기부 금액이 일치하지 않거나 기부가 완료되지 않았습니다.");
      }
    } catch (error) {
      console.error("기부 정보 처리 중 오류:", error);
      res.status(500).send("기부 처리 중 오류가 발생했습니다.");
    }
  });
  

    //결제
    app.post("/payments/complete", async (req, res) => {
      if (!req.session.userId) {
          return res.status(401).send("로그인이 필요합니다.");
      }
  
      const { imp_uid, merchant_uid } = req.body;
  
      try {
          // IAMPORT에서 액세스 토큰(access token) 발급 받기
          const getToken = await axios({
              url: "https://api.iamport.kr/users/getToken",
              method: "post",
              headers: { "Content-Type": "application/json" },
              data: {
                  imp_key: "1471171078525537",
                  imp_secret: "Mb4B4gD5toMmhYPVl3n58GizvTvRPHAeLsOUI2dNmgommP6qbvVESOCQFn9u7C6Rz7KArvGmG0IgF3rM"
              }
          });
          const { access_token } = getToken.data.response;
  
          // imp_uid로 결제 정보 조회
          const getPaymentData = await axios({
              url: `https://api.iamport.kr/payments/${imp_uid}`,
              method: "get",
              headers: { "Authorization": access_token }
          });
          const paymentData = getPaymentData.data.response;
  
          if (paymentData.status === "paid") {
              const db = client.db("myboard");
              const accounts = db.collection("account");
  
              // 현재 날짜와 한 달 후 날짜 계산
              const startDate = new Date();
              const endDate = new Date(startDate.getFullYear(), startDate.getMonth() + 1, startDate.getDate());
  
              // 데이터베이스에서 사용자 정보 업데이트
              const updateResult = await accounts.updateOne(
                  { _id: new ObjectId(req.session.userId) },
                  {
                      $set: {
                          subscriber: true,
                          start_date: startDate,
                          end_date: endDate
                      },
                      $push: {
                        sub_history: {
                            pay_name: "도독 스탠다드", // 요금제 이름
                            pay_date: new Date()  // 결제 날짜
                        }
                    }
                }
              );
  
              if (updateResult.modifiedCount === 1) {
                  // 세션 정보 업데이트
                  req.session.subscriber = true;
                  req.session.save(err => {
                      if (err) {
                          console.error("세션 저장 실패:", err);
                          return res.status(500).send("세션 저장 실패");
                      }
                      res.send("구독 정보가 성공적으로 업데이트되었습니다.");
                  });
              } else {
                  res.status(500).send("구독 정보 업데이트에 실패하였습니다.");
              }
          } else {
              res.status(400).send("결제가 완료되지 않았습니다.");
          }
      } catch (error) {
          console.error("결제 정보 업데이트 중 오류 발생:", error);
          res.status(500).send("서버 내부 오류가 발생했습니다.");
      }
  });
  
  

  app.post("/yearpayments/complete", async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).send("로그인이 필요합니다.");
    }

    const { imp_uid, merchant_uid } = req.body;

    try {
        // IAMPORT에서 액세스 토큰(access token) 발급 받기
        const getToken = await axios({
            url: "https://api.iamport.kr/users/getToken",
            method: "post",
            headers: { "Content-Type": "application/json" },
            data: {
                imp_key: "1471171078525537",
                imp_secret: "Mb4B4gD5toMmhYPVl3n58GizvTvRPHAeLsOUI2dNmgommP6qbvVESOCQFn9u7C6Rz7KArvGmG0IgF3rM"
            }
        });
        const { access_token } = getToken.data.response;

        // imp_uid로 결제 정보 조회
        const getPaymentData = await axios({
            url: `https://api.iamport.kr/payments/${imp_uid}`,
            method: "get",
            headers: { "Authorization": access_token }
        });
        const paymentData = getPaymentData.data.response;

        if (paymentData.status === "paid") {
            const db = client.db("myboard");
            const accounts = db.collection("account");

            // 현재 날짜와 한 달 후 날짜 계산
            const startDate = new Date();
            const endDate = new Date(startDate.getFullYear() + 1, startDate.getMonth(), startDate.getDate());

            // 데이터베이스에서 사용자 정보 업데이트
            const updateResult = await accounts.updateOne(
                { _id: new ObjectId(req.session.userId) },
                {
                    $set: {
                        subscriber: true,
                        start_date: startDate,
                        end_date: endDate
                    },
                    $push: {
                      sub_history: {
                          pay_name: "도독 연간 구독", // 요금제 이름
                          pay_date: new Date()  // 결제 날짜
                      }
                  }
              }
            );

            if (updateResult.modifiedCount === 1) {
                // 세션 정보 업데이트
                req.session.subscriber = true;
                req.session.save(err => {
                    if (err) {
                        console.error("세션 저장 실패:", err);
                        return res.status(500).send("세션 저장 실패");
                    }
                    res.send("구독 정보가 성공적으로 업데이트되었습니다.");
                });
            } else {
                res.status(500).send("구독 정보 업데이트에 실패하였습니다.");
            }
        } else {
            res.status(400).send("결제가 완료되지 않았습니다.");
        }
    } catch (error) {
        console.error("결제 정보 업데이트 중 오류 발생:", error);
        res.status(500).send("서버 내부 오류가 발생했습니다.");
    }
});

// 한 달 연장 결제 완료 API
app.post("/extend_payments/complete", async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).send("로그인이 필요합니다.");
  }

  const { imp_uid, merchant_uid } = req.body;

  try {
    // IAMPORT에서 액세스 토큰(access token) 발급 받기
    const getToken = await axios({
      url: "https://api.iamport.kr/users/getToken",
      method: "post",
      headers: { "Content-Type": "application/json" },
      data: {
        imp_key: "1471171078525537",
        imp_secret: "Mb4B4gD5toMmhYPVl3n58GizvTvRPHAeLsOUI2dNmgommP6qbvVESOCQFn9u7C6Rz7KArvGmG0IgF3rM"
      }
    });
    const { access_token } = getToken.data.response;

    // imp_uid로 결제 정보 조회
    const getPaymentData = await axios({
      url: `https://api.iamport.kr/payments/${imp_uid}`,
      method: "get",
      headers: { "Authorization": access_token }
    });
    const paymentData = getPaymentData.data.response;

    if (paymentData.status === "paid") {
      const db = client.db("myboard");
      const accounts = db.collection("account");
      
      // 데이터베이스에서 현재 구독자 정보 가져오기
      const user = await accounts.findOne({ _id: new ObjectId(req.session.userId) });
      if (!user) {
        return res.status(404).send("계정을 찾을 수 없습니다.");
      }

      // 기존 end_date를 기준으로 한 달 후 날짜 계산
      const newEndDate = new Date(user.end_date);
      newEndDate.setMonth(newEndDate.getMonth() + 1);

      // 데이터베이스에서 사용자 정보 업데이트
      const updateResult = await accounts.updateOne(
        { _id: new ObjectId(req.session.userId) },
        {
          $set: {
            subscriber: true,
            end_date: newEndDate
          },
          $push: {
            sub_history: {
              pay_name: "도독 한 달 연장권",
              pay_date: new Date()
            }
          }
        }
      );

      if (updateResult.modifiedCount === 1) {
        // 세션 정보 업데이트
        req.session.subscriber = true;
        req.session.save(err => {
          if (err) {
            console.error("세션 저장 실패:", err);
            return res.status(500).send("세션 저장 실패");
          }
          res.send("구독 정보가 성공적으로 업데이트되었습니다.");
        });
      } else {
        res.status(500).send("구독 정보 업데이트에 실패하였습니다.");
      }
    } else {
      res.status(400).send("결제가 완료되지 않았습니다.");
    }
  } catch (error) {
    console.error("결제 정보 업데이트 중 오류 발생:", error);
    res.status(500).send("서버 내부 오류가 발생했습니다.");
  }
});

// 1년 연장 결제 완료 API
app.post("/extend_yearpayments/complete", async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).send("로그인이 필요합니다.");
  }

  const { imp_uid, merchant_uid } = req.body;

  try {
    // IAMPORT에서 액세스 토큰(access token) 발급 받기
    const getToken = await axios({
      url: "https://api.iamport.kr/users/getToken",
      method: "post",
      headers: { "Content-Type": "application/json" },
      data: {
        imp_key: "1471171078525537",
        imp_secret: "Mb4B4gD5toMmhYPVl3n58GizvTvRPHAeLsOUI2dNmgommP6qbvVESOCQFn9u7C6Rz7KArvGmG0IgF3rM"
      }
    });
    const { access_token } = getToken.data.response;

    // imp_uid로 결제 정보 조회
    const getPaymentData = await axios({
      url: `https://api.iamport.kr/payments/${imp_uid}`,
      method: "get",
      headers: { "Authorization": access_token }
    });
    const paymentData = getPaymentData.data.response;

    if (paymentData.status === "paid") {
      const db = client.db("myboard");
      const accounts = db.collection("account");
      
      // 데이터베이스에서 현재 구독자 정보 가져오기
      const user = await accounts.findOne({ _id: new ObjectId(req.session.userId) });
      if (!user) {
        return res.status(404).send("계정을 찾을 수 없습니다.");
      }

      // 기존 end_date를 기준으로 한 달 후 날짜 계산
      const newEndDate = new Date(user.end_date);
      newEndDate.setFullYear(newEndDate.getFullYear() + 1);

      // 데이터베이스에서 사용자 정보 업데이트
      const updateResult = await accounts.updateOne(
        { _id: new ObjectId(req.session.userId) },
        {
          $set: {
            subscriber: true,
            end_date: newEndDate
          },
          $push: {
            sub_history:{
              pay_name: "도독 1년 연장권",
              pay_date: new Date()
            }
          }
        }
      );

      if (updateResult.modifiedCount === 1) {
        // 세션 정보 업데이트
        req.session.subscriber = true;
        req.session.save(err => {
          if (err) {
            console.error("세션 저장 실패:", err);
            return res.status(500).send("세션 저장 실패");
          }
          res.send("구독 정보가 성공적으로 업데이트되었습니다.");
        });
      } else {
        res.status(500).send("구독 정보 업데이트에 실패하였습니다.");
      }
    } else {
      res.status(400).send("결제가 완료되지 않았습니다.");
    }
  } catch (error) {
    console.error("결제 정보 업데이트 중 오류 발생:", error);
    res.status(500).send("서버 내부 오류가 발생했습니다.");
  }
});






// Fetch inquiries written by the logged-in user
app.get("/my-inquiries", async (req, res) => {
  if (!req.session.email) {
    return res.status(401).send("로그인이 필요합니다.");
  }

  try {
    const email = req.session.email; // Get email from session
    const supports = await db.collection("support")
      .find({ email: email })
      .sort({ createdAt: -1 }) // Sort by createdAt in descending order
      .toArray();
    res.status(200).json(supports);
  } catch (error) {
    console.error("My Inquiry fetch error:", error);
    res.status(500).send("서버 에러");
  }
});

// Update a post by ID
app.put("/posts/:id", async (req, res) => {
  const { id } = req.params;
  const { category, title, content } = req.body;

  if (!ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: "Invalid post ID" });
  }

  if (!req.session.email) {
      return res.status(401).json({ success: false, message: "로그인이 필요합니다." });
  }

  try {
      const post = await db.collection("post").findOne({ _id: new ObjectId(id) });

      if (!post) {
          return res.status(404).json({ success: false, message: "Post not found" });
      }

      // Ensure only the author can edit the post
      if (post.email !== req.session.email) {
          return res.status(403).json({ success: false, message: "You are not allowed to edit this post." });
      }

      const result = await db.collection("post").updateOne(
          { _id: new ObjectId(id) },
          { $set: { category, title, content, updatedAt: new Date() } }
      );

      if (result.modifiedCount === 1) {
          res.status(200).json({ success: true, message: "Post updated successfully" });
      } else {
          res.status(500).json({ success: false, message: "Failed to update the post." });
      }
  } catch (error) {
      console.error("Error updating post:", error);
      res.status(500).json({ success: false, message: "Server error" });
  }
});


// Update a support post by ID// Update a support post by IDapp.put("/supports/:id", async (req, res) => {
   
  app.put("/supports/:id", async (req, res) => {
    const { id } = req.params;
    const { category, title, content } = req.body;

    if (!ObjectId.isValid(id)) {
        return res.status(400).json({ success: false, message: "Invalid support ID" });
    }

    if (!req.session.email) {
        return res.status(401).json({ success: false, message: "로그인이 필요합니다." });
    }

    try {
        const support = await db.collection("support").findOne({ _id: new ObjectId(id) });

        if (!support) {
            return res.status(404).json({ success: false, message: "Support post not found" });
        }

        // Ensure only the author can edit
        if (support.email !== req.session.email) {
            return res.status(403).json({ success: false, message: "You are not allowed to edit this post." });
        }

        const result = await db.collection("support").updateOne(
            { _id: new ObjectId(id) },
            { $set: { category, title, content, updatedAt: new Date() } }
        );

        if (result.modifiedCount === 1) {
            res.status(200).json({ success: true, message: "Support post updated successfully" });
        } else {
            res.status(500).json({ success: false, message: "Failed to update the support post." });
        }
    } catch (error) {
        console.error("Error updating support post:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});



    // MongoDB 연결 성공 후 Express 서버 설정
    app.use(express.static(path.join(__dirname, "PUBLIC")));
    app.use(express.static(path.join(__dirname, "PUBLIC", "signup")));

    // 라우트 설정(Node.js와 html 서버 연동)
    app.get("/", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "index.html"));
    });

    app.get("/board", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "BOARD", "board.html"));
    });

    app.get("/signup", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "SIGNUP", "signup.html"));
    });

    app.get("/find-account", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "find-account.html"));
    });

    app.get("/main", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "main.html"));
    });

    app.get("/support", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "SUPPORT", "support.html"));
    });

    app.get("/donnvol", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "donnvol.html"));
    });

    app.get("/donation", function(req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "donation.html"));
    });

    app.get("/donationpay", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "donationpay.html"));
    });    
   
    app.get("/volunteer", function(req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "volunteer.html"));
    });

    app.get("/leaderboard", function(req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "leaderboard.html"));
    });
  
  
    app.get("/sharing", function(req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "sharing.html"));
    });

    app.get("/sharing-writing", function(req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "sharing-writing.html"));
    });

    app.get("/mypage", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "mypage.html"));
    });

    app.get("/admin", (req, res) => {
      if (!req.session.admin_state) {
          return res.status(403).send('<script>alert("관리자만 접근할 수 있습니다."); window.location.href="/";</script>');
      }
      res.sendFile(path.join(__dirname, "PUBLIC", "admin.html"));
  });
  

    app.get("/account", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "account.html"));
    });

    app.get("/subscribemanage", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "subscribemanage.html"));
    });

    app.get("/pay", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "pay.html"));
    });

    app.get("/extend_pay", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "extend_pay.html"));
    });
  
    app.get("/wish", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "wish.html"));
    });

    app.get("/watch", requireSubscription, (req, res) => {
      res.sendFile(path.join(__dirname, "PUBLIC", "watch.html"));
    });

    app.get("/watch/video", requireSubscription, (req, res) => {
      res.sendFile(path.join(__dirname, "PUBLIC", "video.html"));
    });

    app.get("/watch/movie", requireSubscription, (req, res) => {
      res.sendFile(path.join(__dirname, "PUBLIC", "movie.html"));
    });

    app.get("/watch/series", requireSubscription, (req, res) => {
      res.sendFile(path.join(__dirname, "PUBLIC", "series.html"));
    });

    app.get("/terms", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "terms.html"));
    });

    app.get("/youthpolicy", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "youthpolicy.html"));
    });

    app.get("/privacypolicy", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "privacypolicy.html"));
    });

    app.get("/board/edit", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC","BOARD", "edit.html"));
    });

    app.get("/support/edit-support", (req, res) => {
      res.sendFile(path.join(__dirname, "PUBLIC", "SUPPORT", "edit-support.html"));
  });

    // 정적 파일 제공을 위한 경로 설정
    app.use("/board", express.static(path.join(__dirname, "BOARD")));
    app.use("/support", express.static(path.join(__dirname, "SUPPORT")));

    app.get("/board", async function (req, res) {
      try {
        const posts = await db.collection("post").find({}).toArray();
        res.render("board", { data: posts });
      } catch (err) {
        console.error("게시글 불러오기 실패:", err);
        res.status(500).send("서버 에러");
      }
    });

    app.get("/support", async function (req, res) {
      try {
        const supports = await db.collection("support").find({}).toArray();
        res.render("support", { data: supports });
      } catch (err) {
        console.error("게시글 불러오기 실패:", err);
        res.status(500).send("서버 에러");
      }
    });

    app.get("/board/post", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "BOARD", "post.html"));
    });

    app.get("/support/supportpost", function (req, res) {
      res.sendFile(path.join(__dirname, "PUBLIC", "SUPPORT", "supportpost.html"));
    });

    // 서버 8070 포트에서 대기

    app.listen(8070, function () {
      console.log("포트 8070으로 서버 대기중..");
    });
    /* https 서버 시작
        https.createServer(httpsOptions, app).listen(8070, () => {
            console.log('HTTPS server running on https://localhost:8070');
        });*/
  } catch (err) {
    console.error("몽고DB 접속 실패:", err);
    client.close();
    process.exit(1); // MongoDB 연결 실패 시 서버 시작을 중단
  }
}

// 서버 시작 함수 호출
startServer();

/*
//MySQL + Node.js 접속 코드
var mysql = require("mysql");
var conn = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"0915",
    database:"myboard",
});


conn.connect();
*/