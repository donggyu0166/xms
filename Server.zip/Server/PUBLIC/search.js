function toggleSearch() {
  const searchContainer = document.getElementById("search-container");
  if (
    searchContainer.style.display === "none" ||
    searchContainer.style.display === ""
  ) {
    searchContainer.style.display = "flex";
  } else {
    searchContainer.style.display = "none";
  }
}

document.addEventListener("click", function (event) {
  const searchContainer = document.getElementById("search-container");
  const searchIcon = document.querySelector(".search-icon");

  if (
    !searchIcon.contains(event.target) &&
    !searchContainer.contains(event.target)
  ) {
    searchContainer.style.display = "none";
  }
});

function search() {
  const query = document.getElementById("search-input").value.toLowerCase();
  const resultsContainer = document.getElementById("results-container");
  resultsContainer.innerHTML = "";

  const results = data.filter((item) => item.toLowerCase().includes(query));

  if (results.length > 0) {
    results.forEach((result) => {
      const resultItem = document.createElement("div");
      resultItem.textContent = result;
      resultsContainer.appendChild(resultItem);
    });
  } else {
    resultsContainer.textContent = "검색 결과가 없습니다.";
  }
}
