document.getElementById("profilePicture").addEventListener("click", function() {
  var dropdownMenu = document.getElementById("dropdownMenu");
  dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
});

// 선택 사항: 메뉴 외부를 클릭했을 때 드롭다운을 닫는 기능
window.addEventListener("click", function(event) {
  if (!event.target.matches('.profile-picture')) {
      var dropdowns = document.getElementsByClassName("dropdown-menu");
      for (var i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.style.display === "block") {
              openDropdown.style.display = "none";
          }
      }
  }
});