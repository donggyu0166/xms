function toggleNotifications() {
  const dropdown = document.getElementById("notification-dropdown");
  if (dropdown.style.display === "none" || dropdown.style.display === "") {
    dropdown.style.display = "block";
  } else {
    dropdown.style.display = "none";
  }
}

document.addEventListener("click", function (event) {
  const dropdown = document.getElementById("notification-dropdown");
  const icon = document.querySelector(".notification-icon");

  // 클릭한 요소가 아이콘 또는 드롭다운 내에 없는 경우 드롭다운을 닫음
  if (!icon.contains(event.target) && !dropdown.contains(event.target)) {
    dropdown.style.display = "none";
  }
});
