/* function showPaymentForm(plan) {
  const paymentForm = document.getElementById("payment-form");
  paymentForm.classList.remove("hidden");

  // 요금제 선택 시 동작을 위한 로직 (예: 요금제에 따라 다른 처리)
  console.log("선택한 요금제:", plan);
} */

function changeCardNumber1() {
  const cardNumber1 = document.getElementById("cardNumber1").value;
  if (cardNumber1.length == 4) {
    document.getElementById("cardNumber2").focus();
  }
  checkForm();
}

function changeCardNumber2() {
  const cardNumber2 = document.getElementById("cardNumber2").value;
  if (cardNumber2.length == 4) {
    document.getElementById("cardNumber3").focus();
  }
  checkForm();
}

function changeCardNumber3() {
  const cardNumber3 = document.getElementById("cardNumber3").value;
  if (cardNumber3.length == 4) {
    document.getElementById("cardNumber4").focus();
  }
  checkForm();
}

function changeCardNumber4() {
  const cardNumber4 = document.getElementById("cardNumber4").value;
  checkForm();
}

function changeExpirationDate1() {
  const expirationDate1 = document.getElementById("expirationDate1").value;
  if (expirationDate1.length == 2) {
    document.getElementById("expirationDate2").focus();
  }
  checkForm();
}

function changeExpirationDate2() {
  const expirationDate2 = document.getElementById("expirationDate2").value;
  checkForm();
}

// 모든 입력 확인 함수
function checkForm() {
  const cardOwner = document.getElementById("cardOwner").value;
  const cardNumber1 = document.getElementById("cardNumber1").value;
  const cardNumber2 = document.getElementById("cardNumber2").value;
  const cardNumber3 = document.getElementById("cardNumber3").value;
  const cardNumber4 = document.getElementById("cardNumber4").value;
  const expirationDate1 = document.getElementById("expirationDate1").value;
  const expirationDate2 = document.getElementById("expirationDate2").value;
  const cvc = document.getElementById("cvc").value;
  const birthdate = document.getElementById("birthdate").value;

  const isFormFilled =
    cardOwner &&
    cardNumber1 &&
    cardNumber2 &&
    cardNumber3 &&
    cardNumber4 &&
    expirationDate1 &&
    expirationDate2 &&
    cvc &&
    birthdate;

  const payButton = document.getElementById("payButton");
  payButton.disabled = !isFormFilled;

  if (isFormFilled) {
    payButton.style.backgroundColor = "#c5e1a5";
    payButton.style.cursor = "pointer";
  } else {
    payButton.style.backgroundColor = "#cccccc";
    payButton.style.cursor = "not-allowed";
  }
}

// 카드 소유주 성명 유효성 검사
function validateCardOwner(cardOwner) {
  const namePattern = /^[가-힣a-zA-Z\s]+$/; // 한글 또는 영어
  const isValid = namePattern.test(cardOwner);
  document.getElementById("cardOwnerError").innerHTML = isValid
    ? ""
    : "한글 또는 영어로 입력해 주세요.";
  return isValid;
}

// 카드 번호 유효성 검사
function validateCardNumber(
  cardNumber1,
  cardNumber2,
  cardNumber3,
  cardNumber4
) {
  const cardPattern = /^\d{4}$/; // 4자리 숫자
  const isValid =
    cardPattern.test(cardNumber1) &&
    cardPattern.test(cardNumber2) &&
    cardPattern.test(cardNumber3) &&
    cardPattern.test(cardNumber4);
  document.getElementById("cardNumberError").innerHTML = isValid
    ? ""
    : "형식이 올바르지 않습니다.";
  return isValid;
}

// 만료일 유효성 검사
function validateExpirationDate(expirationDate1, expirationDate2) {
  const expirationPattern = /^(0[1-9]|1[0-2])$/; // MM 형식
  const isValid =
    expirationPattern.test(expirationDate1) &&
    expirationPattern.test(expirationDate2);
  document.getElementById("expirationDateError").innerHTML = isValid
    ? ""
    : "형식이 올바르지 않습니다.";
  return isValid;
}

// CVC 유효성 검사
function validateCvc(cvc) {
  const cvcPattern = /^\d{3}$/; // 3자리 숫자
  const isValid = cvcPattern.test(cvc);
  document.getElementById("cvcError").innerHTML = isValid
    ? ""
    : "형식이 올바르지 않습니다.";
  return isValid;
}

// 생년월일 유효성 검사
function validateBirthdate(birthdate) {
  const birthdatePattern = /^\d{4}-\d{2}-\d{2}$/; // YYYY-MM-DD 형식
  const isValid = birthdatePattern.test(birthdate);
  document.getElementById("birthdateError").innerHTML = isValid
    ? ""
    : "형식이 올바르지 않습니다.";
  return isValid;
}

// 결제 체크
function payCheck() {
  let cardOwner = document.getElementById("cardOwner").value;
  let cardNumber1 = document.getElementById("cardNumber1").value;
  let cardNumber2 = document.getElementById("cardNumber2").value;
  let cardNumber3 = document.getElementById("cardNumber3").value;
  let cardNumber4 = document.getElementById("cardNumber4").value;
  let expirationDate1 = document.getElementById("expirationDate1").value;
  let expirationDate2 = document.getElementById("expirationDate2").value;
  let cvc = document.getElementById("cvc").value;
  let birthdate = document.getElementById("birthdate").value;
  let check = true;

  // 카드 소유주 성명 확인
  if (!validateCardOwner(cardOwner)) {
    check = false;
  }

  // 카드 번호 확인
  if (!validateCardNumber(cardNumber1, cardNumber2, cardNumber3, cardNumber4)) {
    check = false;
  }

  // 만료일 확인
  if (!validateExpirationDate(expirationDate1, expirationDate2)) {
    check = false;
  }

  // CVC 확인
  if (!validateCvc(cvc)) {
    check = false;
  }

  // 생년월일 확인
  if (!validateBirthdate(birthdate)) {
    check = false;
  }

  // 유효성 검사를 통과한 경우
  if (check) {
    alert("결제가 완료되었습니다.");
  }
}
