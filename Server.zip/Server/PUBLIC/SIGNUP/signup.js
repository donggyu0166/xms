function changePhone1() {
  const phone1 = document.getElementById("phone1").value;
  if (phone1.length === 3) {
    document.getElementById("phone2").focus();
  }
  checkForm();
}

function changePhone2() {
  const phone2 = document.getElementById("phone2").value;
  if (phone2.length === 4) {
    document.getElementById("phone3").focus();
  }
  checkForm();
}

function changePhone3() {
  const phone3 = document.getElementById("phone3").value;
  checkForm();
}

// 이름 형식 확인 함수 (한글 또는 영어)
function validateName(name) {
  const namePattern = /^[가-힣a-zA-Z]+$/;
  const isValid = namePattern.test(name);
  document.getElementById("nameError").innerHTML = isValid
    ? ""
    : "이름은 한글 또는 영어로 입력해 주세요.";
  return isValid;
}

// 닉네임 형식 확인 함수 (한글 또는 영어)
function validateNickName(nickname) {
  const nicknamePattern = /^[가-힣a-zA-Z]+$/;
  const isValid = nicknamePattern.test(nickname);
  document.getElementById("nicknameError").innerHTML = isValid
    ? ""
    : "닉네임은 한글 또는 영어로 입력해 주세요.";
  return isValid;
}

// 전화번호 형식 확인 함수
function validatePhone(phone1, phone2, phone3) {
  const phonePattern = /^\d+$/;
  const isValid =
    phonePattern.test(phone1) &&
    phonePattern.test(phone2) &&
    phonePattern.test(phone3);
  document.getElementById("phoneError").innerHTML = isValid
    ? ""
    : "전화번호는 숫자로만 입력해 주세요.";
  return isValid;
}

// 이메일 형식 확인 함수
function validateEmail(email) {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isValid = emailPattern.test(email);
  document.getElementById("emailError").innerHTML = isValid
    ? ""
    : "이메일 형식이 올바르지 않습니다.";
  return isValid;
}

// 회원가입 버튼 활성화
function checkForm() {
  const email = document.getElementById("email").value;
  const name = document.getElementById("name").value;
  const nickname = document.getElementById("nickname").value;
  const password = document.getElementById("password").value;
  const passwordCheck = document.getElementById("passwordCheck").value;
  const phone1 = document.getElementById("phone1").value;
  const phone2 = document.getElementById("phone2").value;
  const phone3 = document.getElementById("phone3").value;
  const gender_man = document.getElementById("gender_man").checked;
  const gender_woman = document.getElementById("gender_woman").checked;

  const isFormFilled =
    email &&
    name &&
    nickname &&
    password &&
    passwordCheck &&
    phone1 &&
    phone2 &&
    phone3 &&
    (gender_man || gender_woman);

  const isFormValid =
    validateEmail(email) &&
    validateName(name) &&
    validateNickName(nickname) &&
    validatePhone(phone1, phone2, phone3) &&
    password === passwordCheck &&
    isEmailChecked &&
    isNicknameChecked;

  const signUpButton = document.getElementById("signUpButton");
  signUpButton.disabled = !(isFormFilled && isFormValid);

  // 버튼 색깔 설정
  if (!signUpButton.disabled) {
    signUpButton.style.backgroundColor = "#c5e1a5"; // 연두색
    signUpButton.style.cursor = "pointer"; // 활성화 시 커서 포인터로 변경
  } else {
    signUpButton.style.backgroundColor = "#cccccc"; // 비활성화 회색
    signUpButton.style.cursor = "not-allowed"; // 비활성화 시 커서 기본
  }
}

// 회원가입 버튼 클릭 시 유효성 검사 및 제출
function signUpCheck() {
  const email = document.getElementById("email").value;
  const name = document.getElementById("name").value;
  const nickname = document.getElementById("nickname").value;
  const password = document.getElementById("password").value;
  const passwordCheck = document.getElementById("passwordCheck").value;
  const phone1 = document.getElementById("phone1").value;
  const phone2 = document.getElementById("phone2").value;
  const phone3 = document.getElementById("phone3").value;
  const gender_man = document.getElementById("gender_man").checked;
  const gender_woman = document.getElementById("gender_woman").checked;

  let isValid = true;
  let errorMessage = "";

  // 유효성 검사
  if (!validateEmail(email)) {
    errorMessage += "이메일 형식이 올바르지 않습니다.\n";
    isValid = false;
  }
  if (!validateName(name)) {
    errorMessage += "이름은 한글 또는 영어로 입력해 주세요.\n";
    isValid = false;
  }
  if (!validateNickName(nickname)) {
    errorMessage += "닉네임은 한글 또는 영어로 입력해 주세요.\n";
    isValid = false;
  }
  if (password !== passwordCheck || password === "" || passwordCheck === "") {
    document.getElementById("passwordCheckError").innerHTML =
      "비밀번호가 일치하지 않습니다.";
    errorMessage += "비밀번호가 일치하지 않습니다.\n";
    isValid = false;
  } else {
    document.getElementById("passwordCheckError").innerHTML = "";
  }
  if (!validatePhone(phone1, phone2, phone3)) {
    errorMessage += "전화번호는 숫자로만 입력해 주세요.\n";
    isValid = false;
  }
  if (!gender_man && !gender_woman) {
    errorMessage += "성별을 선택해 주세요.\n";
    isValid = false;
  } else {
    document.getElementById("genderError").innerHTML = "";
  }

  // 유효성 검사 실패 시 한 번만 알림 표시
  if (!isValid) {
    alert(errorMessage.trim());
  } else {
    submitForm();
  }
}

function submitForm() {
  const email = document.getElementById("email").value;
  const name = document.getElementById("name").value;
  const userpw = document.getElementById("password").value;
  const nickname = document.getElementById("nickname").value;
  const phone =
    document.getElementById("phone1").value +
    "-" +
    document.getElementById("phone2").value +
    "-" +
    document.getElementById("phone3").value;
  const gender = document.querySelector('input[name="gender"]:checked').value;

  fetch("/register", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email,
      name,
      userpw,
      nickname,
      phone,
      gender,
    }),
  })
    .then((response) => {
      if (response.ok) {
        alert("계정이 성공적으로 생성되었습니다.");
        window.location.href = "/";
      } else {
        return response.text().then((text) => {
          alert(text); // 서버에서 온 오류 메시지를 alert로 표시
        });
      }
    })
    .catch((error) => console.error("Error:", error));
}

// 중복 등록 방지를 위해 이미 등록된 경우 다시 추가하지 않도록 처리
document
  .getElementById("signUpButton")
  .removeEventListener("click", signUpCheck);
document.getElementById("signUpButton").addEventListener("click", signUpCheck);

let isEmailChecked = false;
let isNicknameChecked = false;

// 이메일 중복 확인 함수
function checkEmailDuplicate() {
  const email = document.getElementById("email").value;
  fetch(`/check-duplicate?email=${email}`)
    .then((response) => response.text())
    .then((text) => {
      if (text === "중복된 이메일이 없습니다.") {
        document.getElementById("emailDuplicateResult").innerText =
          "사용 가능한 이메일입니다.";
        isEmailChecked = true;
      } else {
        document.getElementById("emailDuplicateResult").innerText = text;
        isEmailChecked = false;
      }
      checkForm();
    });
}

function checkNicknameDuplicate() {
  const nickname = document.getElementById("nickname").value;
  fetch(`/check-duplicate?nickname=${nickname}`)
    .then((response) => response.text())
    .then((text) => {
      if (text === "중복된 닉네임이 없습니다.") {
        document.getElementById("nicknameDuplicateResult").innerText =
          "사용 가능한 닉네임입니다.";
        isNicknameChecked = true;
      } else {
        document.getElementById("nicknameDuplicateResult").innerText = text;
        isNicknameChecked = false;
      }
      checkForm();
    });
}
