function changePhone1() {
  const phone1 = document.getElementById("phone1").value;
  if (phone1.length === 3) {
    document.getElementById("phone2").focus();
  }
  checkForm();
}

function changePhone2() {
  const phone2 = document.getElementById("phone2").value;
  if (phone2.length === 4) {
    document.getElementById("phone3").focus();
  }
  checkForm();
}

function changePhone3() {
  const phone3 = document.getElementById("phone3").value;
  checkForm();
}

// 모든 입력 확인 함수
function checkForm() {
  const email = document.getElementById("email").value;
  const name = document.getElementById("name").value;
  const nickname = document.getElementById("nickname").value;
  const password = document.getElementById("password").value;
  const passwordCheck = document.getElementById("passwordCheck").value;
  const phone1 = document.getElementById("phone1").value;
  const phone2 = document.getElementById("phone2").value;
  const phone3 = document.getElementById("phone3").value;
  const gender_man = document.getElementById("gender_man").checked;
  const gender_woman = document.getElementById("gender_woman").checked;

  const isFormFilled =
    email &&
    name &&
    nickname &&
    password &&
    passwordCheck &&
    phone1 &&
    phone2 &&
    phone3 &&
    (gender_man || gender_woman);

  const signUpButton = document.getElementById("signUpButton");
  signUpButton.disabled = !isFormFilled;

  // 버튼 색깔 설정
  if (isFormFilled) {
    signUpButton.style.backgroundColor = "#c5e1a5"; // 연두색
    signUpButton.style.cursor = "pointer"; // 활성화 시 커서 포인터로 변경
  } else {
    signUpButton.style.backgroundColor = "#cccccc"; // 비활성화 회색
    signUpButton.style.cursor = "not-allowed"; // 비활성화 시 커서 기본
  }
}

// 이메일 형식 확인 함수
function validateEmail(email) {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isValid = emailPattern.test(email);
  document.getElementById("emailError").innerHTML = isValid
    ? ""
    : "이메일 형식이 올바르지 않습니다.";
  return isValid;
}

// 이름 형식 확인 함수 (한글 또는 영어)
function validateName(name) {
  const namePattern = /^[가-힣a-zA-Z]+$/;
  const isValid = namePattern.test(name);
  document.getElementById("nameError").innerHTML = isValid
    ? ""
    : "이름은 한글 또는 영어로 입력해 주세요.";
  return isValid;
}

// 이름 형식 확인 함수 (한글 또는 영어)
function validateNickName(nickname) {
  const nicknamePattern = /^[가-힣a-zA-Z]+$/;
  const isValid = nicknamePattern.test(nickname);
  document.getElementById("nicknameError").innerHTML = isValid
    ? ""
    : "닉네임은 한글 또는 영어로 입력해 주세요.";
  return isValid;
}

// 전화번호 형식 확인 함수
function validatePhone(phone1, phone2, phone3) {
  const phonePattern = /^\d+$/;
  const isValid =
    phonePattern.test(phone1) &&
    phonePattern.test(phone2) &&
    phonePattern.test(phone3);
  document.getElementById("phoneError").innerHTML = isValid
    ? ""
    : "전화번호는 숫자로만 입력해 주세요.";
  return isValid;
}

// 가입부분 체크
function signUpCheck() {
  let email = document.getElementById("email").value;
  let name = document.getElementById("name").value;
  let nickname = document.getElementById("nickname").value;
  let password = document.getElementById("password").value;
  let passwordCheck = document.getElementById("passwordCheck").value;
  let gender_man = document.getElementById("gender_man").checked;
  let gender_woman = document.getElementById("gender_woman").checked;
  let check = true;

  // 이메일 확인
  if (!validateEmail(email)) {
    check = false;
  }

  // 이름 확인
  if (!validateName(name)) {
    check = false;
  }

  // 닉네임 확인
  if (!validateNickName(nickname)) {
    check = false;
  }

  // 비밀번호 확인
  if (password !== passwordCheck) {
    document.getElementById("passwordError").innerHTML = "";
    document.getElementById("passwordCheckError").innerHTML =
      "비밀번호가 동일하지 않습니다.";
    check = false;
  } else {
    document.getElementById("passwordError").innerHTML = "";
    document.getElementById("passwordCheckError").innerHTML = "";
  }

  if (password === "") {
    document.getElementById("passwordError").innerHTML =
      "비밀번호를 입력해주세요.";
    check = false;
  }

  if (passwordCheck === "") {
    document.getElementById("passwordCheckError").innerHTML =
      "비밀번호를 다시 입력해주세요.";
    check = false;
  }

  // 전화번호 확인
  const phone1 = document.getElementById("phone1").value;
  const phone2 = document.getElementById("phone2").value;
  const phone3 = document.getElementById("phone3").value;

  if (!validatePhone(phone1, phone2, phone3)) {
    check = false;
  }

  // 성별 확인
  if (!gender_man && !gender_woman) {
    document.getElementById("genderError").innerHTML = "성별을 선택해주세요.";
    check = false;
  } else {
    document.getElementById("genderError").innerHTML = "";
  }

  // 유효성 검사를 통과한 경우
  if (check) {
    alert("회원가입이 완료되었습니다.");
  }
}
